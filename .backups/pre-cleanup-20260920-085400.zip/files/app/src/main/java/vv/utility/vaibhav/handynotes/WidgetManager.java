package vv.utility.vaibhav.handynotes;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.preference.PreferenceManager;
import android.util.Log;
import android.widget.RemoteViews;

import java.util.ArrayList;

public class WidgetManager extends AppWidgetProvider {
    public static String ACTION_PREV_NOTE = "vv.utility.vaibhav.handynotes.PREV_NOTE";
    public static String ACTION_NEXT_NOTE = "vv.utility.vaibhav.handynotes.NEXT_NOTE";

    @Override
    public void onUpdate(Context ctxt, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        for (int appWidgetId : appWidgetIds) {
            DBHelper mydb = new DBHelper(ctxt);
            Intent svcIntent = new Intent(ctxt, WidgetService.class);

            SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(ctxt);
            int selectedNoteId = prefs.getInt("widget_note_" + appWidgetId, -1);

            ArrayList<Integer> allNoteIds = getAllNoteIds(mydb);

            if (selectedNoteId == -1 || !allNoteIds.contains(selectedNoteId)) {
                if (!allNoteIds.isEmpty()) {
                    selectedNoteId = allNoteIds.get(0);
                    SharedPreferences.Editor editor = prefs.edit();
                    editor.putInt("widget_note_" + appWidgetId, selectedNoteId);
                    editor.apply();
                } else {
                    continue;
                }
            }

            String noteText = mydb.getNote(selectedNoteId);

            svcIntent.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, appWidgetId);
            svcIntent.putExtra("text", noteText);
            svcIntent.putExtra("noteId", selectedNoteId);

            setupWidget(ctxt, appWidgetManager, appWidgetId, selectedNoteId, svcIntent);
        }

        super.onUpdate(ctxt, appWidgetManager, appWidgetIds);
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        super.onReceive(context, intent);

        if (ACTION_PREV_NOTE.equals(intent.getAction()) || ACTION_NEXT_NOTE.equals(intent.getAction())) {
            int appWidgetId = intent.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID);

            if (appWidgetId == AppWidgetManager.INVALID_APPWIDGET_ID && intent.getData() != null) {
                try {
                    String uriString = intent.getData().toString();
                    String[] parts = uriString.split("/");
                    if (parts.length > 0) {
                        appWidgetId = Integer.parseInt(parts[parts.length - 1]);
                    }
                } catch (Exception e) {
                    // Ignore parsing errors
                }
            }

            if (appWidgetId != AppWidgetManager.INVALID_APPWIDGET_ID) {
                DBHelper dbHelper = new DBHelper(context);
                SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(context);
                int currentNoteId = prefs.getInt("widget_note_" + appWidgetId, -1);

                if (currentNoteId == -1) {
                    ArrayList<Integer> noteIds = getAllNoteIds(dbHelper);
                    if (!noteIds.isEmpty()) {
                        currentNoteId = noteIds.get(0);
                        SharedPreferences.Editor editor = prefs.edit();
                        editor.putInt("widget_note_" + appWidgetId, currentNoteId);
                        editor.commit();
                    } else {
                        return;
                    }
                }

                int newNoteId;
                if (ACTION_PREV_NOTE.equals(intent.getAction())) {
                    newNoteId = getPreviousNoteId(dbHelper, currentNoteId);
                } else {
                    newNoteId = getNextNoteId(dbHelper, currentNoteId);
                }

                if (newNoteId != -1) {
                    SharedPreferences.Editor editor = prefs.edit();
                    editor.putInt("widget_note_" + appWidgetId, newNoteId);
                    editor.commit();

                    AppWidgetManager appWidgetManager = AppWidgetManager.getInstance(context);
                    updateWidgetDirectly(context, appWidgetManager, appWidgetId, newNoteId);
                }
            }
        }
    }

    @Override
    public void onDeleted(Context context, int[] appWidgetIds) {
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(context);
        SharedPreferences.Editor editor = prefs.edit();
        for (int appWidgetId : appWidgetIds) {
            editor.remove("widget_note_" + appWidgetId);
        }
        editor.commit();
        super.onDeleted(context, appWidgetIds);
    }

    private void updateWidgetDirectly(Context context, AppWidgetManager appWidgetManager, int appWidgetId, int noteId) {
        try {
            DBHelper dbHelper = new DBHelper(context);
            String noteText = dbHelper.getNote(noteId);
            if (noteText == null || noteText.equals("NULL")) {
                noteText = "";
            }

            SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(context);
            SharedPreferences.Editor editor = prefs.edit();
            editor.putInt("widget_note_" + appWidgetId, noteId);
            editor.commit();

            Intent svcIntent = new Intent(context, WidgetService.class);
            svcIntent.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, appWidgetId);
            svcIntent.putExtra("text", noteText);
            svcIntent.putExtra("noteId", noteId);

            setupWidget(context, appWidgetManager, appWidgetId, noteId, svcIntent);
        } catch (Exception e) {
            Log.e("WidgetManager", "Error updating widget: " + e.getMessage());
            int[] appWidgetIds = {appWidgetId};
            onUpdate(context, appWidgetManager, appWidgetIds);
        }
    }

    private void setupWidget(Context context, AppWidgetManager appWidgetManager, int appWidgetId, int noteId, Intent svcIntent) {
        RemoteViews widget = new RemoteViews(context.getPackageName(), R.layout.widget_layout);

        DBHelper dbHelper = new DBHelper(context);
        String noteName = dbHelper.getNoteName(noteId);
        if (noteName == null || noteName.equals("NULL") || noteName.trim().isEmpty()) {
            noteName = "";
        } else {
            noteName = noteName.trim();
        }

        String noteText = dbHelper.getNote(noteId);
        if (noteText == null || noteText.equals("NULL")) {
            noteText = "";
        }

        svcIntent.putExtra("text", noteText);
        svcIntent.putExtra("noteId", noteId);

        widget.setTextViewText(R.id.widgetNoteName, noteName);

        String uniqueUri = "widget://" + appWidgetId + "/" + noteId + "/" + System.currentTimeMillis();
        svcIntent.setData(Uri.parse(uniqueUri));

        widget.setRemoteAdapter(appWidgetId, R.id.widgetListView, svcIntent);

        Intent clickIntent = new Intent(context, EditWidget.class);
        clickIntent.putExtra("noteId", noteId);
        clickIntent.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, appWidgetId);
        PendingIntent clickPI = PendingIntent.getActivity(context, appWidgetId * 10, clickIntent, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        widget.setPendingIntentTemplate(R.id.widgetListView, clickPI);

        Intent prevIntent = new Intent(context, WidgetManager.class);
        prevIntent.setAction(ACTION_PREV_NOTE);
        prevIntent.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, appWidgetId);
        prevIntent.setData(Uri.parse("widget://prev/" + appWidgetId));
        PendingIntent prevPI = PendingIntent.getBroadcast(context, appWidgetId * 10 + 1, prevIntent, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        widget.setOnClickPendingIntent(R.id.prevNoteButton, prevPI);

        Intent nextIntent = new Intent(context, WidgetManager.class);
        nextIntent.setAction(ACTION_NEXT_NOTE);
        nextIntent.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, appWidgetId);
        nextIntent.setData(Uri.parse("widget://next/" + appWidgetId));
        PendingIntent nextPI = PendingIntent.getBroadcast(context, appWidgetId * 10 + 2, nextIntent, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        widget.setOnClickPendingIntent(R.id.nextNoteButton, nextPI);

        appWidgetManager.updateAppWidget(appWidgetId, widget);
        appWidgetManager.notifyAppWidgetViewDataChanged(appWidgetId, R.id.widgetListView);
    }

    private int getNextNoteId(DBHelper dbHelper, int currentNoteId) {
        ArrayList<Integer> noteIds = getAllNoteIds(dbHelper);
        if (noteIds.isEmpty()) {
            return -1;
        }

        int currentIndex = noteIds.indexOf(currentNoteId);
        if (currentIndex == -1) {
            return noteIds.get(0);
        }

        int nextIndex = (currentIndex + 1) % noteIds.size();
        return noteIds.get(nextIndex);
    }

    private int getPreviousNoteId(DBHelper dbHelper, int currentNoteId) {
        ArrayList<Integer> noteIds = getAllNoteIds(dbHelper);
        if (noteIds.isEmpty()) {
            return -1;
        }

        int currentIndex = noteIds.indexOf(currentNoteId);
        if (currentIndex == -1) {
            return noteIds.get(0);
        }

        int prevIndex = (currentIndex - 1 + noteIds.size()) % noteIds.size();
        return noteIds.get(prevIndex);
    }

    private ArrayList<Integer> getAllNoteIds(DBHelper dbHelper) {
        ArrayList<Integer> noteIds = new ArrayList<>();
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT " + DBHelper.NOTE_ID + " FROM " + DBHelper.NOTES_TABLE_NAME + " ORDER BY " + DBHelper.NOTE_ID, null);
        if (cursor != null) {
            if (cursor.moveToFirst()) {
                do {
                    noteIds.add(cursor.getInt(0));
                } while (cursor.moveToNext());
            }
            cursor.close();
        }
        return noteIds;
    }
}
