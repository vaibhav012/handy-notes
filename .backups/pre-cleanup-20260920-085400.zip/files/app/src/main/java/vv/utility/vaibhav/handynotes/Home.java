package vv.utility.vaibhav.handynotes;

import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import java.util.ArrayList;

public class Home extends AppCompatActivity implements CustomAdapter.TalkToActivity {

    DBHelper mydb;

    int noteIdForOptions = -1;

    ListView noteListView;
    RelativeLayout optionsLayout;
    TextView noNote;
    Button addNote;
    LinearLayout addNoteLayout;

    ArrayList<Integer> noteIdList;
    ArrayList<String> noteNameList;

    @Override
    protected void onResume() {
        super.onResume();
        if (mydb != null) {
            refreshArrayList();
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        Toolbar myToolbar = findViewById(R.id.home_toolbar);
        setSupportActionBar(myToolbar);

        mydb = new DBHelper(this);

        noteIdList = new ArrayList<>();
        noteNameList = new ArrayList<>();

        optionsLayout = findViewById(R.id.optionsLayout);
        noNote = findViewById(R.id.noNote);
        addNoteLayout = findViewById(R.id.addNoteLayout);
        noteListView = findViewById(R.id.noteListView);
        addNote = findViewById(R.id.addNote);
        final Button addNoteButton = findViewById(R.id.addNoteButton);
        final EditText addNoteName = findViewById(R.id.addNoteName);
        final EditText addNoteNote = findViewById(R.id.addNoteNote);
        final Button deleteNote = findViewById(R.id.deleteNote);

        refreshArrayList();

        addNoteButton.setOnClickListener(v -> {
            addNoteLayout.setVisibility(View.GONE);
            addNote.setVisibility(View.VISIBLE);
            int noteId = mydb.createNoteId();
            String noteName = addNoteName.getText().toString().trim();
            String note = addNoteNote.getText().toString().trim();
            if (note.isEmpty()) {
                Toast.makeText(getBaseContext(), "Cannot add empty note", Toast.LENGTH_SHORT).show();
            } else {
                if (noteName.isEmpty()) {
                    noteName = note;
                }
                mydb.addNote(noteId, noteName, note);
                refreshArrayList();
                addNoteNote.getText().clear();
                addNoteName.getText().clear();
                updateWidget();
            }
        });

        addNote.setOnClickListener(v -> showAddNoteLayout());

        deleteNote.setOnClickListener(v -> {
            mydb.deleteNote(noteIdForOptions);
            refreshArrayList();
            noteIdForOptions = -1;
            optionsLayout.setVisibility(View.GONE);
            updateWidget();
        });
    }

    @Override
    public void showOptions(int noteId) {
        noteIdForOptions = noteId;
        optionsLayout.setVisibility(View.VISIBLE);
    }

    @Override
    public void onBackPressed() {
        if (optionsLayout.getVisibility() == View.VISIBLE) {
            noteIdForOptions = -1;
            optionsLayout.setVisibility(View.GONE);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.action_bar_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.action_export_import) {
            Intent intent = new Intent(getBaseContext(), ExportImportActivity.class);
            startActivity(intent);
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public void refreshArrayList() {
        noteIdList.clear();
        noteNameList.clear();

        SQLiteDatabase db = mydb.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT " + DBHelper.NOTE_ID + ", " + DBHelper.NOTE_NAME + ", " + DBHelper.NOTE + " FROM " + DBHelper.NOTES_TABLE_NAME + " ORDER BY " + DBHelper.NOTE_ID, null);
        if (cursor != null) {
            if (cursor.moveToFirst()) {
                do {
                    int noteId = cursor.getInt(0);
                    String noteName = cursor.getString(1);
                    String noteText = cursor.getString(2);

                    if (noteName == null || noteName.trim().isEmpty() || noteName.equals("NULL")) {
                        noteName = (noteText != null && !noteText.equals("NULL")) ? noteText : "Untitled";
                    }
                    noteIdList.add(noteId);
                    noteNameList.add(noteName.trim());
                } while (cursor.moveToNext());
            }
            cursor.close();
        }

        if (noteIdList.isEmpty()) {
            noNote.setVisibility(View.VISIBLE);
            noteListView.setAdapter(null);
        } else {
            noNote.setVisibility(View.GONE);
            noteListView.setAdapter(new CustomAdapter(this, noteIdList, noteNameList));
        }
    }

    public void showAddNoteLayout() {
        if (addNote.getVisibility() == View.VISIBLE) {
            addNoteLayout.setVisibility(View.VISIBLE);
            addNote.setVisibility(View.GONE);
        } else {
            addNoteLayout.setVisibility(View.GONE);
            addNote.setVisibility(View.VISIBLE);
        }
    }

    public void updateWidget() {
        Intent intent = new Intent(getBaseContext(), WidgetManager.class);
        intent.setAction("android.appwidget.action.APPWIDGET_UPDATE");
        int[] ids = AppWidgetManager.getInstance(getApplication()).getAppWidgetIds(new ComponentName(getApplication(), WidgetManager.class));
        intent.putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, ids);
        sendBroadcast(intent);
    }
}
