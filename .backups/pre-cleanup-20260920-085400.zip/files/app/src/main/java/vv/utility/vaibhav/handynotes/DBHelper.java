package vv.utility.vaibhav.handynotes;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class DBHelper extends SQLiteOpenHelper {

    public static final String DATABASE_NAME = "VVHandyNotes.db";
    public static final String NOTES_TABLE_NAME = "notes";
    public static final String NOTE_ID = "noteId";
    public static final String NOTE_NAME = "noteName";
    public static final String NOTE = "note";
    public static final String DATE_TIME_COLUMN = "dateTime";

    public DBHelper(Context context) {
        super(context, DATABASE_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + NOTES_TABLE_NAME + "( " + NOTE_ID + " INTEGER PRIMARY KEY, " + NOTE_NAME + " TEXT, " + NOTE + " TEXT, " + DATE_TIME_COLUMN + " TEXT );");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + NOTES_TABLE_NAME);
        onCreate(db);
    }

    public void addNote(int noteId, String name, String note) {
        SQLiteDatabase db = this.getWritableDatabase();

        Calendar calendar = Calendar.getInstance();
        String dateAndTime = "Date : " + calendar.get(Calendar.DATE) + "/" + calendar.get(Calendar.MONTH) + "/" + calendar.get(Calendar.YEAR) +
                "  Time : " + calendar.get(Calendar.HOUR_OF_DAY) + "." + calendar.get(Calendar.MINUTE) + "." + calendar.get(Calendar.SECOND);

        ContentValues values = new ContentValues();
        values.put(NOTE_ID, noteId);
        values.put(NOTE_NAME, name);
        values.put(NOTE, note);
        values.put(DATE_TIME_COLUMN, dateAndTime);
        db.insertWithOnConflict(NOTES_TABLE_NAME, null, values, SQLiteDatabase.CONFLICT_REPLACE);
    }

    public int createNoteId() {
        SQLiteDatabase db = this.getReadableDatabase();
        int maxId = 0;
        Cursor cursor = db.rawQuery("SELECT MAX(" + NOTE_ID + ") FROM " + NOTES_TABLE_NAME, null);
        if (cursor != null) {
            if (cursor.moveToFirst()) {
                maxId = cursor.getInt(0);
            }
            cursor.close();
        }
        return maxId + 1;
    }

    public String getNoteName(int note_id) {
        SQLiteDatabase db = this.getReadableDatabase();
        String noteName = "NULL";
        Cursor cursor = db.rawQuery("SELECT " + NOTE_NAME + " FROM " + NOTES_TABLE_NAME + " WHERE " + NOTE_ID + " = ?", new String[]{String.valueOf(note_id)});
        if (cursor != null) {
            if (cursor.moveToFirst()) {
                noteName = cursor.getString(0);
            }
            cursor.close();
        }
        return noteName != null ? noteName : "NULL";
    }

    public String getNote(int note_id) {
        SQLiteDatabase db = this.getReadableDatabase();
        String note = "NULL";
        Cursor cursor = db.rawQuery("SELECT " + NOTE + " FROM " + NOTES_TABLE_NAME + " WHERE " + NOTE_ID + " = ?", new String[]{String.valueOf(note_id)});
        if (cursor != null) {
            if (cursor.moveToFirst()) {
                note = cursor.getString(0);
            }
            cursor.close();
        }
        return note != null ? note : "NULL";
    }

    public String getDateTime(int note_id) {
        SQLiteDatabase db = this.getReadableDatabase();
        String dateTime = "NULL";
        Cursor cursor = db.rawQuery("SELECT " + DATE_TIME_COLUMN + " FROM " + NOTES_TABLE_NAME + " WHERE " + NOTE_ID + " = ?", new String[]{String.valueOf(note_id)});
        if (cursor != null) {
            if (cursor.moveToFirst()) {
                dateTime = cursor.getString(0);
            }
            cursor.close();
        }
        return dateTime != null ? dateTime : "NULL";
    }

    public void deleteNote(int noteId) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(NOTES_TABLE_NAME, NOTE_ID + " = ?", new String[]{String.valueOf(noteId)});
    }

    public void updateNote(int noteId, String noteName, String note) {
        SQLiteDatabase db = this.getWritableDatabase();

        Calendar calendar = Calendar.getInstance();
        String dateAndTime = "Date : " + calendar.get(Calendar.DATE) + "/" + calendar.get(Calendar.MONTH) + "/" + calendar.get(Calendar.YEAR) +
                "  Time : " + calendar.get(Calendar.HOUR_OF_DAY) + "." + calendar.get(Calendar.MINUTE) + "." + calendar.get(Calendar.SECOND);

        ContentValues values = new ContentValues();
        values.put(NOTE_NAME, noteName);
        values.put(NOTE, note);
        values.put(DATE_TIME_COLUMN, dateAndTime);
        db.update(NOTES_TABLE_NAME, values, NOTE_ID + " = ?", new String[]{String.valueOf(noteId)});
    }

    public int getCount() {
        SQLiteDatabase db = this.getReadableDatabase();
        int count = 0;
        Cursor cursor = db.rawQuery("SELECT COUNT(*) FROM " + NOTES_TABLE_NAME, null);
        if (cursor != null) {
            if (cursor.moveToFirst()) {
                count = cursor.getInt(0);
            }
            cursor.close();
        }
        return count;
    }

    // Get all notes as a list of Note objects for export
    public List<Note> getAllNotes() {
        List<Note> notes = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + NOTES_TABLE_NAME + " ORDER BY " + NOTE_ID, null);
        if (cursor != null) {
            if (cursor.moveToFirst()) {
                do {
                    int noteId = cursor.getInt(0);
                    String noteName = cursor.getString(1);
                    String note = cursor.getString(2);
                    String dateTime = cursor.getString(3);

                    if (noteName != null && !noteName.trim().isEmpty() && !noteName.equals("NULL")) {
                        notes.add(new Note(noteId, noteName, note, dateTime));
                    }
                } while (cursor.moveToNext());
            }
            cursor.close();
        }
        return notes;
    }

    // Import notes from a list (used after parsing JSON)
    public void importNotes(List<Note> notes) {
        SQLiteDatabase db = this.getWritableDatabase();
        for (Note note : notes) {
            ContentValues values = new ContentValues();
            values.put(NOTE_ID, note.getNoteId());
            values.put(NOTE_NAME, note.getNoteName());
            values.put(NOTE, note.getNote());
            values.put(DATE_TIME_COLUMN, note.getDateTime());
            db.insertWithOnConflict(NOTES_TABLE_NAME, null, values, SQLiteDatabase.CONFLICT_REPLACE);
        }
    }

    // Clear all notes (useful before import)
    public void clearAllNotes() {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(NOTES_TABLE_NAME, null, null);
    }

    // Note data class for export/import
    public static class Note {
        private final int noteId;
        private final String noteName;
        private final String note;
        private final String dateTime;

        public Note(int noteId, String noteName, String note, String dateTime) {
            this.noteId = noteId;
            this.noteName = noteName;
            this.note = note;
            this.dateTime = dateTime;
        }

        public int getNoteId() { return noteId; }
        public String getNoteName() { return noteName; }
        public String getNote() { return note; }
        public String getDateTime() { return dateTime; }
    }
}
