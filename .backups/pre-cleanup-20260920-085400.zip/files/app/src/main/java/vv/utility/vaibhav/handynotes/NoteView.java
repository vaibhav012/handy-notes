package vv.utility.vaibhav.handynotes;

import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class NoteView extends AppCompatActivity {

    private int noteId = 0;
    private DBHelper mydb;
    private EditText noteNote;
    private EditText noteName;
    private String originalNoteText = "";
    private String originalNoteName = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_note_view);

        Toolbar myToolbar = findViewById(R.id.note_view_toolbar);
        setSupportActionBar(myToolbar);

        ActionBar ab = getSupportActionBar();
        if (ab != null) {
            ab.setDisplayHomeAsUpEnabled(true);
        }

        Intent intent = getIntent();
        mydb = new DBHelper(this);

        if (intent != null) {
            if (intent.hasExtra("noteId")) {
                try {
                    noteId = intent.getIntExtra("noteId", -1);
                    if (noteId == -1) {
                        String idStr = intent.getStringExtra("noteId");
                        if (idStr != null) {
                            noteId = Integer.parseInt(idStr);
                        }
                    }
                } catch (Exception e) {
                    noteId = 0;
                }
            }
        }

        noteName = findViewById(R.id.noteName);
        noteNote = findViewById(R.id.noteNote);
        TextView dateAndTime = findViewById(R.id.dateAndTime);

        String noteNameStr = mydb.getNoteName(noteId);
        if (noteNameStr == null || noteNameStr.equals("NULL")) {
            noteNameStr = "";
        }
        originalNoteName = noteNameStr.trim();
        noteName.setText(originalNoteName);

        String noteTextStr = mydb.getNote(noteId);
        if (noteTextStr == null || noteTextStr.equals("NULL")) {
            noteTextStr = "";
        }
        originalNoteText = noteTextStr.trim();
        noteNote.setText(originalNoteText);

        String dateTimeStr = mydb.getDateTime(noteId);
        if (dateTimeStr == null || dateTimeStr.equals("NULL")) {
            dateTimeStr = "";
        }
        dateAndTime.setText(formatDateTime(dateTimeStr.trim()));

        // Auto-focus the EditText and show keyboard
        noteNote.requestFocus();
        noteNote.setSelection(noteNote.getText().length());
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE);

        // Set up save button
        Button saveButton = findViewById(R.id.saveButton);
        saveButton.setOnClickListener(v -> saveNote());

        // Set up cancel button
        Button cancelButton = findViewById(R.id.cancelButton);
        cancelButton.setOnClickListener(v -> finish());
    }

    private void saveNote() {
        String noteText = noteNote.getText().toString().trim();
        String newNoteName = noteName.getText().toString().trim();

        if (newNoteName.isEmpty()) {
            newNoteName = originalNoteName;
            noteName.setText(newNoteName);
        }

        mydb.updateNote(noteId, newNoteName, noteText);
        originalNoteText = noteText;
        originalNoteName = newNoteName;

        updateWidget();

        Toast.makeText(this, "Note saved", Toast.LENGTH_SHORT).show();
        finish();
    }

    private void updateWidget() {
        Intent intent = new Intent(getBaseContext(), WidgetManager.class);
        intent.setAction("android.appwidget.action.APPWIDGET_UPDATE");
        int[] ids = AppWidgetManager.getInstance(getApplication()).getAppWidgetIds(new ComponentName(getApplication(), WidgetManager.class));
        intent.putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, ids);
        sendBroadcast(intent);
    }

    private String formatDateTime(String dateTimeString) {
        if (dateTimeString == null || dateTimeString.isEmpty()) {
            return "Last Modified: Unknown";
        }
        try {
            Pattern pattern = Pattern.compile("Date : (\\d+)/(\\d+)/(\\d+)\\s+Time : (\\d+)\\.(\\d+)\\.(\\d+)");
            Matcher matcher = pattern.matcher(dateTimeString);

            if (matcher.find()) {
                String dayStr = matcher.group(1);
                String monthStr = matcher.group(2);
                String hourStr = matcher.group(4);
                String minStr = matcher.group(5);

                if (dayStr != null && monthStr != null && hourStr != null && minStr != null) {
                    int day = Integer.parseInt(dayStr);
                    int month = Integer.parseInt(monthStr);
                    int hour = Integer.parseInt(hourStr);
                    int minute = Integer.parseInt(minStr);

                    String[] monthNames = {"Jan", "Feb", "Mar", "Apr", "May", "Jun",
                            "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"};
                    String monthName = (month >= 0 && month < 12) ? monthNames[month] : "Jan";

                    if (hour > 23) {
                        hour = hour % 24;
                    }

                    String ordinal = getOrdinalSuffix(day);
                    String timeString = String.format(Locale.getDefault(), "%02d:%02d", hour, minute);

                    return "Last Modified: " + day + ordinal + " " + monthName + ", " + timeString;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return "Last Modified: " + dateTimeString;
    }

    private String getOrdinalSuffix(int day) {
        if (day >= 11 && day <= 13) {
            return "th";
        }
        switch (day % 10) {
            case 1: return "st";
            case 2: return "nd";
            case 3: return "rd";
            default: return "th";
        }
    }

    @Override
    public void onBackPressed() {
        String currentText = noteNote.getText().toString().trim();
        String currentName = noteName.getText().toString().trim();
        if (!currentText.equals(originalNoteText) || !currentName.equals(originalNoteName)) {
            finish();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.action_bar_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
